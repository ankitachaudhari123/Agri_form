<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
<img src="img/success.gif">
</center>
</body>
</html>